package com.veiltalk.avatar;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.veiltalk.auth.UnauthorizedException;
import com.veiltalk.auth.UserRepository;
import com.veiltalk.auth.ValidationException;
import com.veiltalk.auth.NotFoundException;

@Service
public class AvatarService {

	private static final String INVALID_SESSION_MESSAGE = "Invalid session";
	private static final String AVATAR_NOT_FOUND_MESSAGE = "Avatar not found";
	private static final Pattern HEX_COLOR = Pattern.compile("^#[0-9a-fA-F]{6}$");
	private static final Set<String> COLOR_SLOTS = Set.of("hair", "outfit", "eyes", "accessory", "aura");
	private static final int MAX_MATERIAL_OVERRIDES = 64;

	private final AvatarProfileRepository avatarProfileRepository;
	private final AvatarModelCatalogService catalogService;
	private final UserRepository userRepository;

	public AvatarService(
			AvatarProfileRepository avatarProfileRepository,
			AvatarModelCatalogService catalogService,
			UserRepository userRepository) {
		this.avatarProfileRepository = avatarProfileRepository;
		this.catalogService = catalogService;
		this.userRepository = userRepository;
	}

	@Transactional
	public UpsertResult upsert(UUID authenticatedUserId, AvatarUpsertRequest request) {
		requireActiveUser(authenticatedUserId);
		AvatarModel model = catalogService.findById(request.modelId())
				.orElseThrow(() -> new ValidationException("Invalid model_id"));
		Map<String, Object> customizations = request.customizations() == null
				? Map.of()
				: request.customizations();
		validateCustomizations(model, customizations);

		var existingProfile = avatarProfileRepository.findByUserId(authenticatedUserId);
		AvatarProfile profile = existingProfile.orElseGet(AvatarProfile::new);
		profile.setUserId(authenticatedUserId);
		profile.setModelId(model.id());
		profile.setModelUrl(model.modelUrl());
		profile.setCustomizations(new HashMap<>(customizations));
		avatarProfileRepository.saveAndFlush(profile);
		return new UpsertResult(existingProfile.isEmpty());
	}

	@Transactional(readOnly = true)
	public AvatarProfileResponse getOwnAvatar(UUID authenticatedUserId) {
		requireActiveUser(authenticatedUserId);
		AvatarProfile profile = avatarProfileRepository.findByUserId(authenticatedUserId)
				.orElseThrow(this::avatarNotFound);
		return new AvatarProfileResponse(
				profile.getId(),
				profile.getUserId(),
				profile.getModelId(),
				profile.getModelUrl(),
				profile.getCustomizations(),
				profile.getCreatedAt(),
				profile.getUpdatedAt());
	}

	@Transactional(readOnly = true)
	public AvatarPublicResponse getUserAvatar(UUID userId) {
		if (userRepository.findByIdAndDeletedAtIsNull(userId).isEmpty()) {
			throw avatarNotFound();
		}
		AvatarProfile profile = avatarProfileRepository.findByUserId(userId)
				.orElseThrow(this::avatarNotFound);
		return new AvatarPublicResponse(
				profile.getUserId(),
				profile.getModelId(),
				profile.getModelUrl(),
				profile.getCustomizations());
	}

	private void validateCustomizations(AvatarModel model, Map<String, Object> customizations) {
		Set<String> supportedKeys = Set.copyOf(model.supportedCustomizations());
		for (String key : customizations.keySet()) {
			if (!supportedKeys.contains(key)) {
				throw new ValidationException("Unsupported customization: " + key);
			}
		}
		validateColors(customizations.get("colors"));
		validateMaterialOverrides(customizations.get("materialOverrides"));
	}

	private void validateColors(Object value) {
		if (value == null) return;
		if (!(value instanceof Map<?, ?> colors)) {
			throw new ValidationException("colors must be an object");
		}
		for (var entry : colors.entrySet()) {
			if (!(entry.getKey() instanceof String slot) || !COLOR_SLOTS.contains(slot)) {
				throw new ValidationException("Unsupported color slot");
			}
			if (entry.getValue() != null && !isHexColor(entry.getValue())) {
				throw new ValidationException("Invalid color value");
			}
		}
	}

	private void validateMaterialOverrides(Object value) {
		if (value == null) return;
		if (!(value instanceof Map<?, ?> overrides) || overrides.size() > MAX_MATERIAL_OVERRIDES) {
			throw new ValidationException("Invalid materialOverrides");
		}
		for (var entry : overrides.entrySet()) {
			if (!(entry.getKey() instanceof String key) || key.isBlank() || key.length() > 200
					|| !isHexColor(entry.getValue())) {
				throw new ValidationException("Invalid material override");
			}
		}
	}

	private boolean isHexColor(Object value) {
		return value instanceof String color && HEX_COLOR.matcher(color).matches();
	}

	private void requireActiveUser(UUID authenticatedUserId) {
		if (userRepository.findByIdAndDeletedAtIsNull(authenticatedUserId).isEmpty()) {
			throw new UnauthorizedException(INVALID_SESSION_MESSAGE);
		}
	}

	private NotFoundException avatarNotFound() {
		return new NotFoundException(AVATAR_NOT_FOUND_MESSAGE);
	}

	public record UpsertResult(boolean created) {
	}
}
