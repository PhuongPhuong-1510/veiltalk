package com.veiltalk.video;

import java.time.Instant;
import java.time.Duration;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.veiltalk.auth.ForbiddenException;
import com.veiltalk.auth.ConflictException;
import com.veiltalk.auth.NotFoundException;
import com.veiltalk.auth.ValidationException;
import com.veiltalk.auth.TooManyRequestsException;

import jakarta.persistence.EntityManager;

@Service
public class VideoService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VideoService.class);

	// Chunk đầu tiên của phiên multipart luôn là part số 1.
	private static final int FIRST_PART_NUMBER = 1;

	private final VideoRepository videoRepository;
	private final VideoMultipartStorage multipartStorage;
	private final VideoUploadSessionStore sessionStore;
	private final VideoProperties videoProperties;
	private final EntityManager entityManager;
	private final RedisDistributedLock distributedLock;
	private final VideoMediaValidator mediaValidator;
	private final VideoCleanupTransactionSupport cleanupTransactionSupport;
	@Value("${video.active-upload-limit:3}")
	private int activeUploadLimit = 3;

	public VideoService(
			VideoRepository videoRepository,
			VideoMultipartStorage multipartStorage,
			VideoUploadSessionStore sessionStore,
			VideoProperties videoProperties,
			EntityManager entityManager,
			RedisDistributedLock distributedLock,
			VideoMediaValidator mediaValidator,
			VideoCleanupTransactionSupport cleanupTransactionSupport) {
		this.videoRepository = videoRepository;
		this.multipartStorage = multipartStorage;
		this.sessionStore = sessionStore;
		this.videoProperties = videoProperties;
		this.entityManager = entityManager;
		this.distributedLock = distributedLock;
		this.mediaValidator = mediaValidator;
		this.cleanupTransactionSupport = cleanupTransactionSupport;
	}

	@Transactional
	public CreateVideoResponse initiateUpload(UUID userId, CreateVideoRequest request) {
		if (activeUploadLimit <= 0) throw new IllegalStateException("Video active upload limit must be positive");
		// Hold the user row lock until transaction commit so concurrent backend
		// instances cannot each observe the same free upload slot.
		entityManager.createNativeQuery("SELECT id FROM users WHERE id = :userId FOR UPDATE")
				.setParameter("userId", userId).getSingleResult();
		long activeUploads = videoRepository.findRecordingByUserId(userId).stream()
				.filter(video -> sessionStore.findSession(video.getId()).isPresent()).count();
		if (activeUploads >= activeUploadLimit) {
			throw new TooManyRequestsException(Duration.ofHours(1));
		}
		// 1) Quota (NFR-19): chỉ tính video status='ready'; recording/processing/failed không tính.
		long usedBytes = videoRepository.sumReadyFileSizeBytes(userId);
		if (usedBytes + request.estimatedSizeBytes() > videoProperties.storageLimitBytes()) {
			throw new StorageQuotaExceededException(
					"Dung lượng tài khoản không đủ để chứa video này. Hãy xóa bớt video cũ.");
		}

		String format = StringUtils.hasText(request.format()) ? request.format() : "mp4";
		String safeFormatForKey = format.replaceAll("[^A-Za-z0-9]", "_");

		// 2) Gọi MinIO TRƯỚC khi insert để nếu MinIO lỗi thì không sinh record 'recording' mồ côi.
		// objectKey phải cố định suốt phiên (create → upload part → finalize dùng chung key);
		// dùng một UUID riêng cho key, không phụ thuộc id do DB sinh.
		String storageKey = "videos/" + UUID.randomUUID() + "/source." + safeFormatForKey;
		String uploadId = multipartStorage.createMultipartUpload(storageKey);
		try {
			return finishInitiateUpload(userId, request, format, storageKey, uploadId);
		} catch (RuntimeException exception) {
			try {
				multipartStorage.abortMultipartUpload(storageKey, uploadId);
			} catch (RuntimeException abortException) {
				LOGGER.error("Could not abort failed upload {}; queueing cleanup", storageKey, abortException);
				try {
					cleanupTransactionSupport.recordAbortCleanupJob(null, storageKey, uploadId, Instant.now());
				} catch (RuntimeException queueException) {
					exception.addSuppressed(queueException);
					LOGGER.error("Could not queue multipart cleanup for {}", storageKey, queueException);
				}
			}
			throw exception;
		}
	}

	private CreateVideoResponse finishInitiateUpload(UUID userId, CreateVideoRequest request,
			String format, String storageKey, String uploadId) {
		String firstChunkUrl = multipartStorage.presignPartUrl(storageKey, uploadId, FIRST_PART_NUMBER);

		// 3) Tạo record videos status='recording'. file_size_bytes có CHECK > 0 nên lưu tạm
		// estimated (đã validate > 0); giá trị thật ghi đè khi webhook báo ready (P2-T23).
		Video video = new Video();
		video.setUserId(userId);
		video.setTitle(request.title());
		video.setStoragePath(storageKey);
		video.setUploadId(uploadId);
		video.setFileSizeBytes(request.estimatedSizeBytes());
		video.setFormat(format);
		video.setStatus(VideoStatus.RECORDING);

		videoRepository.saveAndFlush(video);
		// created_at do DB sinh (insertable=false) — refresh để đọc lại giá trị.
		entityManager.refresh(video);

		// 4) Gieo phiên multipart vào Redis để P2-T21 tích lũy ETag theo part.
		// Lỗi ở đây ném ra ⇒ transaction rollback ⇒ không sinh record 'recording' mồ côi.
		// Nếu Redis lỗi, outer catch abort multipart; timeout job không thấy record đã rollback.
		try {
			sessionStore.createSession(
					video.getId(), uploadId, userId, request.chunkSizeBytes());
		} catch (RuntimeException exception) {
			// Không log credential hay URL đã ký — chỉ định danh phiên để lần dấu.
			LOGGER.error("Không thể gieo phiên upload vào Redis cho video {} (objectKey={})",
					video.getId(), storageKey, exception);
			throw new VideoStorageException("Không thể khởi tạo phiên upload", exception);
		}

		return new CreateVideoResponse(
				video.getId(),
				video.getTitle(),
				video.getStatus().getDatabaseValue(),
				uploadId,
				firstChunkUrl,
				FIRST_PART_NUMBER,
				video.getCreatedAt());
	}

	/**
	 * P2-T21 — POST /videos/{id}/chunks: ghi nhận ETag của part vừa PUT (part_number - 1),
	 * kiểm tra thứ tự/idempotency/quota nguyên tử trong Redis, rồi cấp presigned URL cho part
	 * tiếp theo. etag_previous trong request K là ETag của part K-1.
	 */
	@Transactional(readOnly = true)
	public ChunkUrlResponse requestNextChunk(UUID userId, UUID videoId, ChunkUrlRequest request) {
		// 1) Tồn tại + không bị xóa mềm → 404 (đồng thời che luôn 'phiên đã kết thúc').
		Video video = videoRepository.findById(videoId)
				.filter(candidate -> candidate.getDeletedAt() == null)
				.orElseThrow(() -> new NotFoundException(
						"Video không tồn tại hoặc phiên upload đã kết thúc."));

		// 2) Sở hữu → 403.
		if (!video.getUserId().equals(userId)) {
			throw new ForbiddenException("Video không thuộc về bạn.");
		}

		// 3) Chỉ phiên đang quay mới nhận thêm chunk; processing/ready/failed thì phiên đã đóng.
		if (video.getStatus() != VideoStatus.RECORDING) {
			throw new NotFoundException("Phiên upload không còn hiệu lực.");
		}

		// 4) readyBytes từ DB (chỉ video 'ready'); Lua tính quota ước lượng bảo thủ với chunkSize.
		long readyBytes = videoRepository.sumReadyFileSizeBytes(userId);
		VideoUploadSessionStore.ReserveResult result = sessionStore.reserveNextPart(
				videoId,
				request.uploadId(),
				request.partNumber(),
				request.etagPrevious(),
				readyBytes,
				videoProperties.storageLimitBytes());

		switch (result) {
			case OK, RETRY -> {
				// OK: lần đầu cấp part này. RETRY: cấp lại đúng part cũ (không nhân đôi ETag).
				String chunkUrl = multipartStorage.presignPartUrl(
						video.getStoragePath(), request.uploadId(), request.partNumber());
				return new ChunkUrlResponse(
						chunkUrl,
						request.partNumber(),
						videoProperties.presignedUrlExpirySeconds());
			}
			case ERR_NO_SESSION -> throw new NotFoundException(
					"Video không tồn tại hoặc phiên upload đã kết thúc.");
			case ERR_QUOTA -> throw new StorageQuotaExceededException(
					"Dung lượng ước tính đã vượt hạn mức. Hãy dừng và hủy phiên quay này.");
			case ERR_UPLOAD -> throw new ValidationException("upload_id không hợp lệ.");
			case ERR_ETAG -> throw new ValidationException(
					"etag_previous không khớp với ETag đã ghi nhận cho part này.");
			case ERR_ORDER -> throw new ValidationException(
					"part_number không đúng thứ tự của phiên upload.");
			default -> throw new IllegalStateException("Kết quả reserveNextPart không xác định: " + result);
		}
	}

	public FinalizeVideoResponse finalizeUpload(
			UUID userId, UUID videoId, FinalizeVideoRequest request) {
		validateRequestParts(request.parts());
		try (var quotaLock = distributedLock.acquire("video:quota-lock:" + userId);
				var videoLock = distributedLock.acquire("video:operation-lock:" + videoId)) {
			Video video = requireOwnedRecording(userId, videoId);
			VideoUploadSessionStore.UploadSession session = requireSession(videoId);
			validateUploadId(userId, request.uploadId(), session);
			validateRedisEtags(request.parts(), session);

			List<VideoMultipartStorage.UploadedPart> actualParts =
					multipartStorage.listParts(video.getStoragePath(), request.uploadId()).stream()
							.sorted(Comparator.comparingInt(
									VideoMultipartStorage.UploadedPart::partNumber))
							.toList();
			validateMinioParts(request.parts(), actualParts);
			long actualUploadedBytes = sumPartSizes(actualParts);
			long reservedBytes = videoRepository.sumQuotaReservedBytes(userId);
			if (reservedBytes > videoProperties.storageLimitBytes() - actualUploadedBytes) {
				multipartStorage.abortMultipartUpload(video.getStoragePath(), request.uploadId());
				int updated = videoRepository.failAndSoftDeleteRecording(videoId, Instant.now());
				sessionStore.deleteSession(videoId);
				if (updated != 1) {
					throw new VideoOperationConflictException(
							"Trạng thái video đã thay đổi khi xử lý quota.");
				}
				throw new StorageQuotaExceededException(
						"Dung lượng thực tế vượt hạn mức. Phiên quay đã được hủy.");
			}

			// Commit PROCESSING trước khi gọi MinIO. Webhook có thể đến ngay trong lời gọi
			// CompleteMultipartUpload và phải nhìn thấy trạng thái đã commit này.
			int updated = videoRepository.markProcessing(
					videoId, request.durationSecs(), actualUploadedBytes);
			if (updated != 1) {
				throw new VideoOperationConflictException(
						"Video đã được xử lý bởi thao tác khác.");
			}

			try {
				multipartStorage.completeMultipartUpload(
						video.getStoragePath(), request.uploadId(), actualParts);
			} catch (RuntimeException completeFailure) {
				if (reconcileFailedComplete(video, request.uploadId(), actualParts,
						actualUploadedBytes, completeFailure)) {
					sessionStore.deleteSession(videoId);
					return processingResponse(videoId);
				}
				throw completeFailure;
			}
			sessionStore.deleteSession(videoId);
			return processingResponse(videoId);
		}
	}

	private boolean reconcileFailedComplete(
			Video video,
			String uploadId,
			List<VideoMultipartStorage.UploadedPart> parts,
			long expectedBytes,
			RuntimeException completeFailure) {
		try {
			var objectSize = multipartStorage.statObjectSize(video.getStoragePath());
			if (objectSize.isPresent()) {
				if (objectSize.getAsLong() == expectedBytes
						&& mediaValidator.isPlayable(video.getStoragePath(), video.getFormat(), expectedBytes)) {
					videoRepository.markReadyFromWebhook(video.getStoragePath(), expectedBytes);
					return true;
				}
				LOGGER.error("VIDEO_COMPLETE_SIZE_MISMATCH videoId={} expectedBytes={} actualBytes={}",
						video.getId(), expectedBytes, objectSize.getAsLong());
				return false;
			}

			// Chỉ quay lại RECORDING khi MinIO xác nhận multipart vẫn tồn tại và khớp.
			List<VideoMultipartStorage.UploadedPart> remainingParts = multipartStorage
					.listParts(video.getStoragePath(), uploadId).stream()
					.sorted(Comparator.comparingInt(
							VideoMultipartStorage.UploadedPart::partNumber))
					.toList();
			if (remainingParts.equals(parts)) {
				videoRepository.restoreRecording(video.getId());
			}
			return false;
		} catch (RuntimeException reconciliationFailure) {
			completeFailure.addSuppressed(reconciliationFailure);
			LOGGER.error("VIDEO_COMPLETE_RECONCILIATION_FAILED videoId={} objectKey={}",
					video.getId(), video.getStoragePath(), reconciliationFailure);
			return false;
		}
	}

	private FinalizeVideoResponse processingResponse(UUID videoId) {
		return new FinalizeVideoResponse(videoId, VideoStatus.PROCESSING.getDatabaseValue(),
				"Upload hoàn tất, đang xử lý. Trạng thái sẽ cập nhật qua MinIO webhook.");
	}

	/**
	 * P2-T24 — GET /videos (mục 7.1): thư viện video cá nhân, cursor pagination theo
	 * (created_at DESC, id DESC). storage_used_bytes chỉ tính video 'ready' (NFR-19).
	 */
	@Transactional(readOnly = true)
	public VideoLibraryResponse listVideos(UUID userId, String statusFilter, String cursor, int limit) {
		VideoStatus status;
		try {
			status = statusFilter == null ? null : VideoStatus.fromDatabaseValue(statusFilter);
		} catch (IllegalArgumentException exception) {
			throw new ValidationException("status không hợp lệ.");
		}
		VideoCursor decoded = VideoCursor.decode(cursor);
		int pageSize = Math.min(Math.max(limit, 1), 50);

		List<Video> page = status == null
				? videoRepository.findLibraryPage(userId,
						decoded == null ? null : decoded.createdAt(),
						decoded == null ? null : decoded.id(), PageRequest.of(0, pageSize + 1))
				: videoRepository.findLibraryPageByStatus(userId, status,
						decoded == null ? null : decoded.createdAt(),
						decoded == null ? null : decoded.id(), PageRequest.of(0, pageSize + 1));

		boolean hasMore = page.size() > pageSize;
		List<Video> pageItems = hasMore ? page.subList(0, pageSize) : page;
		String nextCursor = hasMore
				? VideoCursor.encode(pageItems.get(pageItems.size() - 1))
				: null;

		List<VideoSummary> summaries = pageItems.stream()
				.map(video -> new VideoSummary(
						video.getId(),
						video.getTitle(),
						video.getStatus().getDatabaseValue(),
						video.getDurationSecs(),
						video.getFileSizeBytes(),
						video.getFormat(),
						video.getCreatedAt()))
				.toList();

		long usedBytes = videoRepository.sumReadyFileSizeBytes(userId);
		return new VideoLibraryResponse(
				summaries, usedBytes, videoProperties.storageLimitBytes(), nextCursor, hasMore);
	}

	/**
	 * P2-T24 — GET /videos/{id} (mục 7.7): view_url chỉ khi status='ready'; failed luôn null.
	 */
	@Transactional(readOnly = true)
	public VideoDetailResponse getVideo(UUID userId, UUID videoId) {
		Video video = requireOwnedVisible(userId, videoId);
		String viewUrl = video.getStatus() == VideoStatus.READY
				? multipartStorage.presignGetUrl(video.getStoragePath())
				: null;
		return toDetailResponse(video, viewUrl);
	}

	/**
	 * P2-T24 — PUT /videos/{id} (mục 7.8): đổi tên, không giới hạn theo status.
	 */
	@Transactional
	public VideoDetailResponse renameVideo(UUID userId, UUID videoId, RenameVideoRequest request) {
		Video video = requireOwnedVisible(userId, videoId);
		int updated = videoRepository.renameVideo(videoId, request.title());
		if (updated != 1) {
			throw new VideoOperationConflictException("Video đã được xử lý bởi thao tác khác.");
		}
		video.setTitle(request.title());
		String viewUrl = video.getStatus() == VideoStatus.READY
				? multipartStorage.presignGetUrl(video.getStoragePath())
				: null;
		return toDetailResponse(video, viewUrl);
	}

	/**
	 * P2-T24 — DELETE /videos/{id} (mục 7.9): soft delete; storage giảm ngay nếu status='ready'
	 * vì quota chỉ tính video ready chưa xóa mềm (idx_videos_user_size). Không gọi MinIO ở đây —
	 * background job dọn file thật sau, theo đúng mô tả API.
	 */
	@Transactional
	public void deleteVideo(UUID userId, UUID videoId) {
		requireOwnedVisible(userId, videoId);
		int updated = videoRepository.softDeleteVideo(videoId, Instant.now());
		if (updated != 1) {
			throw new VideoOperationConflictException("Video đã được xử lý bởi thao tác khác.");
		}
	}

	private Video requireOwnedVisible(UUID userId, UUID videoId) {
		Video video = videoRepository.findById(videoId)
				.filter(candidate -> candidate.getDeletedAt() == null)
				.orElseThrow(() -> new NotFoundException("Video không tồn tại."));
		if (!video.getUserId().equals(userId)) {
			throw new ForbiddenException("Video không thuộc về bạn.");
		}
		return video;
	}

	private VideoDetailResponse toDetailResponse(Video video, String viewUrl) {
		return new VideoDetailResponse(
				video.getId(),
				video.getTitle(),
				video.getStatus().getDatabaseValue(),
				video.getDurationSecs(),
				video.getStatus() == VideoStatus.FAILED ? 0 : video.getFileSizeBytes(),
				video.getFormat(),
				viewUrl,
				video.getCreatedAt(),
				video.getUpdatedAt());
	}

	public void abortUpload(UUID userId, UUID videoId, AbortVideoRequest request) {
		try (var videoLock = distributedLock.acquire("video:operation-lock:" + videoId)) {
			Video video = requireOwnedRecording(userId, videoId);
			VideoUploadSessionStore.UploadSession session = requireSession(videoId);
			validateUploadId(userId, request.uploadId(), session);
			multipartStorage.abortMultipartUpload(video.getStoragePath(), request.uploadId());
			int updated = videoRepository.failAndSoftDeleteRecording(videoId, Instant.now());
			sessionStore.deleteSession(videoId);
			if (updated != 1) {
				throw new VideoOperationConflictException(
						"Video đã được xử lý bởi thao tác khác.");
			}
		}
	}

	private Video requireOwnedRecording(UUID userId, UUID videoId) {
		Video video = videoRepository.findById(videoId)
				.filter(candidate -> candidate.getDeletedAt() == null)
				.orElseThrow(() -> new NotFoundException("Video không tồn tại."));
		if (!video.getUserId().equals(userId)) {
			throw new ForbiddenException("Video không thuộc về bạn.");
		}
		if (video.getStatus() != VideoStatus.RECORDING) {
			throw new ConflictException("Video đã được finalize hoặc không còn ghi hình.");
		}
		return video;
	}

	private VideoUploadSessionStore.UploadSession requireSession(UUID videoId) {
		return sessionStore.findSession(videoId)
				.orElseThrow(() -> new NotFoundException("Phiên upload không tồn tại hoặc đã hết hạn."));
	}

	private void validateUploadId(
			UUID userId, String uploadId, VideoUploadSessionStore.UploadSession session) {
		if (!session.userId().equals(userId) || !session.uploadId().equals(uploadId)) {
			throw new NotFoundException("Phiên upload không tồn tại hoặc upload_id không hợp lệ.");
		}
	}

	private void validateRequestParts(List<FinalizeVideoRequest.PartRequest> parts) {
		for (int index = 0; index < parts.size(); index++) {
			if (parts.get(index).partNumber() != index + 1) {
				throw new ValidationException(
						"parts phải liên tục từ 1..N, đúng thứ tự và không trùng.");
			}
		}
	}

	private void validateRedisEtags(
			List<FinalizeVideoRequest.PartRequest> parts,
			VideoUploadSessionStore.UploadSession session) {
		if (session.nextPartNumber() != parts.size() + 1
				|| session.etags().size() != Math.max(0, parts.size() - 1)) {
			throw new ValidationException("Danh sách parts không khớp thứ tự phiên upload.");
		}
		for (int partNumber = 1; partNumber < parts.size(); partNumber++) {
			String stored = session.etags().get(partNumber);
			if (stored == null || !normalizeEtag(stored).equals(
					normalizeEtag(parts.get(partNumber - 1).etag()))) {
				throw new ValidationException("ETag request không khớp ETag đã lưu trong Redis.");
			}
		}
	}

	private void validateMinioParts(
			List<FinalizeVideoRequest.PartRequest> requestParts,
			List<VideoMultipartStorage.UploadedPart> actualParts) {
		if (actualParts.size() != requestParts.size()) {
			throw new ValidationException("Danh sách parts không đầy đủ trên MinIO.");
		}
		for (int index = 0; index < actualParts.size(); index++) {
			var requested = requestParts.get(index);
			var actual = actualParts.get(index);
			if (actual.partNumber() != requested.partNumber()
					|| !normalizeEtag(actual.etag()).equals(normalizeEtag(requested.etag()))) {
				throw new ValidationException("Part number hoặc ETag không khớp MinIO.");
			}
		}
	}

	private long sumPartSizes(List<VideoMultipartStorage.UploadedPart> parts) {
		try {
			long total = 0;
			for (var part : parts) {
				if (part.sizeBytes() <= 0) {
					throw new ValidationException("MinIO trả về kích thước part không hợp lệ.");
				}
				total = Math.addExact(total, part.sizeBytes());
			}
			return total;
		} catch (ArithmeticException exception) {
			throw new ValidationException("Tổng kích thước video không hợp lệ.");
		}
	}

	static String normalizeEtag(String etag) {
		String value = etag.trim();
		if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
			return value.substring(1, value.length() - 1);
		}
		return value;
	}

}
