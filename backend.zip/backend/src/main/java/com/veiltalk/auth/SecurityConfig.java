package com.veiltalk.auth;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.DispatcherType;

import com.veiltalk.call.CallNotifyAuthenticationFilter;
import com.veiltalk.video.VideoWebhookAuthenticationFilter;

@Configuration
public class SecurityConfig {

	private static final long HSTS_MAX_AGE_SECONDS = 31_536_000;
	private static final String UNAUTHORIZED_RESPONSE =
			"{\"error\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Authentication is required\",\"details\":{}}}";

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	SecurityFilterChain securityFilterChain(
			HttpSecurity http,
			JwtService jwtService,
			JwtBlacklistService jwtBlacklistService,
			UserTokenRevocationService userTokenRevocationService,
			VideoWebhookAuthenticationFilter videoWebhookAuthenticationFilter,
			CallNotifyAuthenticationFilter callNotifyAuthenticationFilter) throws Exception {
		http
				.csrf(AbstractHttpConfigurer::disable)
				.formLogin(AbstractHttpConfigurer::disable)
				.httpBasic(AbstractHttpConfigurer::disable)
				.cors(Customizer.withDefaults())
				.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.exceptionHandling(exceptions -> exceptions.authenticationEntryPoint((request, response, exception) -> {
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					response.setCharacterEncoding(StandardCharsets.UTF_8.name());
					response.setContentType(MediaType.APPLICATION_JSON_VALUE);
					response.getWriter().write(UNAUTHORIZED_RESPONSE);
				}))
				.authorizeHttpRequests(authorize -> authorize
						.dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()
						.requestMatchers(HttpMethod.POST, "/auth/logout").authenticated()
						.requestMatchers(HttpMethod.GET, "/avatars/models").permitAll()
						.requestMatchers("/auth/**", "/actuator/health/**", "/internal/**", "/ws/messaging").permitAll()
						.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
						.anyRequest().authenticated())
				.headers(headers -> headers
						.contentTypeOptions(Customizer.withDefaults())
						.frameOptions(frame -> frame.deny())
						.httpStrictTransportSecurity(hsts -> hsts
								.includeSubDomains(true)
								.maxAgeInSeconds(HSTS_MAX_AGE_SECONDS)))
				.addFilterBefore(
						videoWebhookAuthenticationFilter,
						UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(
						callNotifyAuthenticationFilter,
						UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(
						new JwtAuthenticationFilter(
								jwtService,
								jwtBlacklistService,
								userTokenRevocationService),
						UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}

	@Bean
	FilterRegistrationBean<VideoWebhookAuthenticationFilter> disableServletRegistration(
			VideoWebhookAuthenticationFilter filter) {
		FilterRegistrationBean<VideoWebhookAuthenticationFilter> registration =
				new FilterRegistrationBean<>(filter);
		registration.setEnabled(false);
		return registration;
	}

	@Bean
	FilterRegistrationBean<CallNotifyAuthenticationFilter> disableCallNotifyServletRegistration(
			CallNotifyAuthenticationFilter filter) {
		FilterRegistrationBean<CallNotifyAuthenticationFilter> registration =
				new FilterRegistrationBean<>(filter);
		registration.setEnabled(false);
		return registration;
	}

	@Bean
	CorsConfigurationSource corsConfigurationSource(
			@Value("${app.cors.allowed-origins}") String configuredOrigins) {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.stream(configuredOrigins.split(","))
				.map(String::trim)
				.filter(origin -> !origin.isEmpty())
				.distinct()
				.toList());
		configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		configuration.setAllowedHeaders(List.of(HttpHeaders.AUTHORIZATION, HttpHeaders.CONTENT_TYPE));

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		for (String path : List.of(
				"/auth/**", "/users/**", "/avatars/**", "/conversations/**",
				"/videos/**", "/metrics/**", "/ws/**")) {
			source.registerCorsConfiguration(path, configuration);
		}
		return source;
	}
}
